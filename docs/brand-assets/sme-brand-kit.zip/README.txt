HOW TO USE
1. Copy SmeLogo.jsx to components/ and replace the old logo:  <SmeLogo className="h-9 w-auto" />
2. Import theme.css in your root layout/_app (import "./theme.css"), or merge the variables into globals.css.
3. Tailwind users: paste tailwind.config.snippet.js into theme.extend.
4. Put favicon.svg in /public and add:  <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
   (Next.js app router: rename to app/icon.svg)
5. Plain HTML: use logo.svg with <img src="logo.svg" height="40">.
