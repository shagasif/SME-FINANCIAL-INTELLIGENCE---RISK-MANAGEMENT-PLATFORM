// tailwind.config.js -> theme.extend.colors
colors: {
  ink:    { DEFAULT: "#201e29", 2: "#12101c", 3: "#252131" },
  silver: { 100: "#e1dbea", 300: "#c9c1d8", 500: "#716d7c" },
  violet: { 300: "#b49bff", 500: "#6841b8", 700: "#4a2d8e" },
},
// examples: bg-ink text-silver-100 border-ink-3 bg-violet-500 text-white hover:bg-violet-300
backgroundImage: { "brand-gradient": "linear-gradient(135deg,#b49bff,#6841b8 55%,#4a2d8e)" },
